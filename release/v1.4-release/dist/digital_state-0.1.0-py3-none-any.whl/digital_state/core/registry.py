import os
import json
from typing import Dict, Any, Optional, List

from digital_state.core.exceptions import RegistryError
from digital_state.runtime.store import RuntimeStore
from digital_state.runtime.stores import IdentityRecord


# Built-in trust-root public keys are shipped as a Package asset and consumed by
# the Runtime IdentityStore at Governance Provisioning. They are NOT hardcoded
# here (moved to assets/trust_roots.json; see ADR-011-03/011-04).


class Agent:
    """Represents a registered Agent profile in the Digital State."""

    def __init__(
        self,
        agent_id: str,
        role: str,
        permissions: List[str],
        status: str = "Active",
        public_key: Any = "",
    ):
        self.agent_id = agent_id
        self.role = role
        self.permissions = permissions
        self.status = status
        self.public_key = public_key

    def to_dict(self) -> Dict[str, Any]:
        return {
            "agent_id": self.agent_id,
            "role": self.role,
            "permissions": self.permissions,
            "status": self.status,
            "public_key": self.public_key,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Agent":
        return cls(
            agent_id=data["agent_id"],
            role=data["role"],
            permissions=data["permissions"],
            status=data.get("status", "Active"),
            public_key=data.get("public_key", ""),
        )


class AgentRegistry:
    """First-class Agent Registry managing profiles, statuses, and permissions."""

    def __init__(self, storage_path: str):
        self.storage_path = storage_path
        self.agents: Dict[str, Agent] = {}
        self._load_agents()

    def _load_agents(self) -> None:
        """Load registered agents from registry file (workspace registry)."""
        if not os.path.exists(self.storage_path):
            self._ensure_default_agents()
            return

        try:
            with open(self.storage_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                for agent_id, agent_data in data.items():
                    self.agents[agent_id] = Agent.from_dict(agent_data)
        except (json.JSONDecodeError, KeyError) as e:
            raise RegistryError(f"Failed to parse agent registry file: {e}") from e

    def _save_agents(self) -> None:
        """Persist agents to workspace registry file (legacy/secondary store)."""
        os.makedirs(os.path.dirname(self.storage_path), exist_ok=True)
        data = {agent_id: agent.to_dict() for agent_id, agent in self.agents.items()}
        with open(self.storage_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def get_agent(self, agent_id: str) -> Optional[Agent]:
        """Retrieve an agent profile by identity.

        Resolution order (ADR-011-06 / SPEC-012 CRITICAL-01): the Runtime
        IdentityStore is the AUTHORITATIVE owner of mutable identities. It is
        queried FIRST. The workspace registry is a legacy/secondary source and
        is consulted ONLY when:

          1. the Runtime is unavailable, or
          2. the identity does not exist in the Runtime.

        No execution path may return a workspace identity while a Runtime
        identity for the same identity_id exists.
        """
        try:
            store = RuntimeStore()
            if store.identity.exists():
                rec = store.identity.get(agent_id)
                if rec:
                    return Agent(
                        agent_id=rec.identity_id,
                        role=rec.role,
                        permissions=self._permissions_for_role(rec.role),
                        public_key=rec.public_key,
                        status=rec.status,
                    )
        except Exception:
            # Runtime unavailable: fall through to workspace-only resolution.
            pass

        # Secondary (legacy) source. Reached ONLY when the Runtime is absent or
        # does not hold this identity — never when it does.
        return self.agents.get(agent_id)

    @staticmethod
    def _permissions_for_role(role: str) -> List[str]:
        """Resolve permissions for a role from the Package roles.json asset (ADR-011-03).

        BUG-VAL-001 fix: role keys in roles.json are lowercase ("auditor") while the
        Runtime-provisioned identity stores a capitalized role ("Auditor"). Normalize
        the lookup by lowercasing so every Runtime-seeded identity resolves its real
        permissions instead of silently falling back to [] (which blocked all approval,
        veto, and verification actions for independent users).
        """
        assets = os.path.join(os.path.dirname(__file__), "assets", "roles.json")
        try:
            with open(assets, "r", encoding="utf-8") as f:
                roles = json.load(f).get("roles", {})
            return roles.get(role.strip().lower(), {}).get("permissions", [])
        except (OSError, json.JSONDecodeError):
            return []

    def _ensure_default_agents(self) -> None:
        """Seed baseline trust roots from the Package roles.json asset (data-driven).

        These defaults keep the kernel bootable when no Runtime is present. They
        are intentionally public-key-only (no private keys); real key pairs are
        generated by Governance Provisioning into the Runtime (ADR-011-04).
        """
        assets = os.path.join(os.path.dirname(__file__), "assets", "roles.json")
        try:
            with open(assets, "r", encoding="utf-8") as f:
                role_defs = json.load(f).get("roles", {})
        except (OSError, json.JSONDecodeError):
            return

        # Reuse the shipped public-key trust roots (asset) for the bootable defaults.
        trust = os.path.join(os.path.dirname(__file__), "assets", "trust_roots.json")
        public_keys = {}
        if os.path.exists(trust):
            with open(trust, "r", encoding="utf-8") as f:
                public_keys = json.load(f).get("trust_roots", {})

        for role_key, role_def in role_defs.items():
            identity_id = f"{role_key}-agent"
            public_key = public_keys.get(
                role_key,
                {"key_id": f"key-{role_key}", "status": "Active",
                 "algorithm": "ECDSA_P256", "value": ""},
            )
            self.register_agent(
                agent_id=identity_id,
                role=role_key.capitalize(),
                permissions=role_def.get("permissions", []),
                public_key=public_key,
            )

    def register_agent(
        self, agent_id: str, role: str, permissions: List[str], public_key: Any = "",
        force: bool = False,
    ) -> Agent:
        """Register a new agent in the registry.

        BUG-VAL-002 fix: when ``force`` is set, an existing (e.g. default-seeded)
        identity is overwritten with the supplied keypair instead of raising. This
        lets a user inject their own private key under a canonical trust-root ID
        (prime-agent/builder-agent/auditor-agent) that ``init`` pre-seeds without a
        private key — previously they were stuck: unable to sign as the seeded
        identity (no private key) and unable to re-register (rejected as "already
        registered").
        """
        if agent_id in self.agents and not force:
            raise RegistryError(f"Agent with ID '{agent_id}' is already registered.")
        from digital_state.core.verifier import CryptoVerifier
        CryptoVerifier.validate_key_metadata(public_key)

        agent = Agent(agent_id=agent_id, role=role, permissions=permissions, public_key=public_key)
        self.agents[agent_id] = agent
        self._save_agents()
        return agent

    def update_agent_status(self, agent_id: str, status: str) -> None:
        """Update status of a registered agent profile (e.g. Active or Suspended)."""
        agent = self.get_agent(agent_id)
        if not agent:
            raise RegistryError(f"Agent with ID '{agent_id}' not found in registry.")

        agent.status = status
        self._save_agents()
